import java.util.List;

import javax.swing.JPanel;
import javax.swing.JTextArea;

/**
 * Ein MedienDetailAnzeigerWerkzeug ist ein Werkzeug um die Details von Medien
 * anzuzeigen.
 * 
 * @author SE2-Team
 * @version SoSe 2020
 */
class MedienDetailAnzeigerWerkzeug
{
    private MedienDetailAnzeigerUI _ui;

    /**
     * Initialisiert ein neues MedienDetailAnzeigerWerkzeug.
     */
    public MedienDetailAnzeigerWerkzeug()
    {
        _ui = new MedienDetailAnzeigerUI();
    }

    /**
     * Setzt die Liste der Medien deren Details angezeigt werden sollen.
     * 
     * @param medien Eine Liste von Medien.
     * 
     * @require (medien != null)
     
    public void setMedien(List<Medium> medien)
    {
        assert medien != null : "Vorbedingung verletzt: (medien != null)";
        JTextArea selectedMedienTextArea = _ui.getMedienAnzeigerTextArea();
        // TODO Aufgabe 3.4.2 Die Mediendetails sollen angezeigt werden
        selectedMedienTextArea.setText("");
    }
    */
    /**
    public void setMedien(List<Medium> medien)
    {
        assert medien != null : "Vorbedingung verletzt: (medien != null)";
        JTextArea selectedMedienTextArea = _ui.getMedienAnzeigerTextArea();
        // TODO Aufgabe 3.4.2 Die Mediendetails sollen angezeigt werden
        for (Medium medium : medien)
        {
            if (medium instanceof CD) //TypTest
            {
                CD cd = (CD) medium; //Typzusicherung: downcast vom Typ Medium auf Typ cd
                String interpret = cd.getInterpret();
                int laenge = cd.getSpiellaenge();
                String titel = cd.getTitel();
                String kommentar = cd.getKommentar();
                String bez = cd.getMedienBezeichnung();
                selectedMedienTextArea.setText(bez + "\n");
                selectedMedienTextArea.append(titel + "\n");
                selectedMedienTextArea.append(interpret + "\n");
                selectedMedienTextArea.append("" + laenge + "\n");
                selectedMedienTextArea.append(kommentar);
    
            }
            if (medium instanceof DVD)
            {
                DVD dvd = (DVD) medium;
                String regisseur = dvd.getRegisseur();
                int laufzeit = dvd.getLaufzeit();
                String titel = dvd.getTitel();
                String kommentar = dvd.getKommentar();
                String bez = dvd.getMedienBezeichnung();
                selectedMedienTextArea.setText(bez + "\n");
                selectedMedienTextArea.append(titel + "\n");
                selectedMedienTextArea.append(regisseur + "\n");
                selectedMedienTextArea.append("" + laufzeit + "\n");
                selectedMedienTextArea.append(kommentar);
    
            }
            if (medium instanceof Videospiel)
            {
                Videospiel videospiel = (Videospiel) medium;
                String system = videospiel.getSystem();
                String titel = videospiel.getTitel();
                String kommentar = videospiel.getKommentar();
                String bez = videospiel.getMedienBezeichnung();
                selectedMedienTextArea.setText(bez + "\n");
                selectedMedienTextArea.append(titel + "\n");
                selectedMedienTextArea.append(system + "\n");
                selectedMedienTextArea.append(kommentar);
    
            }
        }
    }
    */
    public void setMedien(List<Medium> medien)
    {
        assert medien != null : "Vorbedingung verletzt: (medien != null)";
        JTextArea selectedMedienTextArea = _ui.getMedienAnzeigerTextArea();
        // TODO Aufgabe 3.4.2 Die Mediendetails sollen angezeigt werden
        for (Medium medium : medien)
        {
            String eigenschaften = medium.getFormatiertenString();
            selectedMedienTextArea.setText(eigenschaften);

        }
    }

    /**
     * Gibt das Panel dieses Subwerkzeugs zurück.
     * 
     * @ensure result != null
     */
    public JPanel getUIPanel()
    {
        return _ui.getUIPanel();
    }
}
