
class Videospiel implements Medium
{
    /**
     * Der Interpret der CD
     */
    private String _system;

    /**
     * Ein Kommentar zum Medium
     */
    private String _kommentar;

    /**
     * Der Titel des Mediums
     * 
     */
    private String _titel;

    public Videospiel(String titel, String kommentar, String system)
    {
        assert titel != null : "Vorbedingung verletzt: titel != null";
        assert kommentar != null : "Vorbedingung verletzt: kommentar != null";
        assert system != null : "Vorbedingung verletzt: system != null";
        _system = system;
        _kommentar = kommentar;
        _titel = titel;

    }

    @Override
    public String getKommentar()
    {
        // TODO Auto-generated method stub
        return _kommentar;
    }

    @Override
    public String getMedienBezeichnung()
    {
        // TODO Auto-generated method stub
        return "Videospiel";
    }

    @Override
    public String getTitel()
    {
        // TODO Auto-generated method stub
        return _titel;
    }

    public String getSystem()
    {
        // TODO Auto-generated method stub
        return _system;
    }

    /**
     * Gibt eine Text Repräsentation aller Eigenschaften der Videospiel zurück
     * 
     * @return Eigenschaften der Videospiel
     * 
     * @require _titel!=null 
     * @require _kommentar!=null
     * @require _system!=null
     * @require getMedienBezeichnung()!=null
     * 
     * @ensure result != null
     */
    @Override
    public String getFormatiertenString()
    {
        //sonst gibt es eine NullPointerException
        //Außerdem wollen wir den Kunden alle Informationen über die Videospiel anzeigen
        assert _titel != null : "Vorbedingung verletzt: _titel!=null";
        assert _kommentar != null : "Vorbedingung verletzt: _kommentar!=null";
        assert _system != null : "Vorbedingung verletzt: _system!=null";
        assert getMedienBezeichnung() != null : "Vorbedingung verletzt: getMedienBezeichnung()!=null";

        String ergebnis = "Bezeichnung: " + getMedienBezeichnung() + "\n"
                + "Titel: " + _titel + "\n" + "System: " + _system + "\n"
                + "Kommentar: " + _kommentar;

        return ergebnis;
    }

}
