package de.uni_hamburg.informatik.swt.se2.kino.werkzeuge.barzahlung;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import de.uni_hamburg.informatik.swt.se2.kino.materialien.Vorstellung;

public class BarZahlungWerkzeug
{
    public BarZahlungWerkzeugUI _ui;

    private Vorstellung _vorstellung;

    private int _preis;

    private int restBetrag = 0;

    public boolean verkaufOK = false;

    /**
     * Initialisiert das BarZahlungWerkzeug.
     */
    public BarZahlungWerkzeug(Vorstellung vorstellung, int preis)
    {
        _ui = new BarZahlungWerkzeugUI();
        _vorstellung = vorstellung;
        _preis = preis;
        registriereUIAktionen();

    }

    private void registriereUIAktionen()
    {

        _ui.getBerechneButton()
            .addActionListener(new ActionListener()
            {
                @Override
                public void actionPerformed(ActionEvent e)
                {
                    if (_ui.getKundenBetrag()
                        .getText()
                        .matches("\\d*"))
                    {
                        berechneRestbetrag();

                    }
                    else
                    {
                        _ui.getFehlerLabel()
                            .setText("Bitte Nummer eingeben");
                    }

                }

            });

        _ui.getOKButton()
            .addActionListener(new ActionListener()
            {

                @Override
                public void actionPerformed(ActionEvent e)
                {
                    if (_ui.getKundenBetrag()
                        .getText()
                        .matches("\\d*"))
                    {
                        berechneRestbetrag();
                        if (restBetrag >= 0)
                        {
                            berechneRestbetrag();
                            verkaufOK = true;

                            //PlatzVerkaufsWerkzeug.verkaufePlaetze(_vorstellung);
                            _ui.getWindow()
                                .setVisible(false);
                        }
                        else
                        {
                            _ui.getFehlerLabel()
                                .setText("Nicht genug Geld !");
                        }

                    }
                    else
                    {
                        _ui.getFehlerLabel()
                            .setText("Bitte Nummer eingeben");
                    }

                }
            });

        _ui.getAbbrechenButton()
            .addActionListener(new ActionListener()
            {
                @Override
                public void actionPerformed(ActionEvent e)
                {
                    _ui.getWindow()
                        .dispose();
                }
            });

        _ui.getVorstellung()
            .setText(_vorstellung.toString());

        _ui.getPreisAnzeige()
            .setText(String.valueOf(_preis));

    }

    private void berechneRestbetrag()
    {

        int kundenBetrag = Integer.parseInt(_ui.getKundenBetrag()
            .getText());

        restBetrag = kundenBetrag - _preis;

        _ui.getRestBetrag()
            .setText(String.valueOf(restBetrag));

    }

}
