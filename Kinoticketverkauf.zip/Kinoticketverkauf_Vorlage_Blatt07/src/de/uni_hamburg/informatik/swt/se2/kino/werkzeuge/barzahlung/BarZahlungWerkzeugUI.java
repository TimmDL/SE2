package de.uni_hamburg.informatik.swt.se2.kino.werkzeuge.barzahlung;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

/**
 * Das UI des {@link BarZahlungWerkzeug}.
 * 
 * @author Duy
 * @version SoSe 2020
 */
public class BarZahlungWerkzeugUI
{
    public JFrame _window;

    private JPanel _panel;

    private JButton _bestätigen;
    private JButton _abbrechen;
    private JButton _berechne;

    private JLabel _labelKundenBetrag;
    private JLabel _labelRestBetrag;
    private JLabel _vorstellung;
    private JLabel _FehlerLabel;
    private JLabel _preis;

    private JTextField _kundenBetrag;

    private JLabel _restBetrag;
    private JLabel _preisAnzeige;

    public BarZahlungWerkzeugUI()
    {
        //erstellt das Fenster
        _window = new JFrame();

        //erstellt den Panel
        _panel = new JPanel();
        //_panel.setBorder(BorderFactory.createEmptyBorder(30, 30, 10, 30));
        _panel.setLayout(null);

        //erstellt den Text KundenBetrag
        _labelKundenBetrag = new JLabel("KundenBetrag: ");
        _labelKundenBetrag.setBounds(10, 120, 200, 25);
        _panel.add(_labelKundenBetrag);

        //erstellt den Feld, wo man Geld eingeben kann
        _kundenBetrag = new JTextField(20);
        _kundenBetrag.setBounds(100, 120, 200, 25);
        _panel.add(_kundenBetrag);

        _labelRestBetrag = new JLabel("Restbetrag: ");
        _labelRestBetrag.setBounds(10, 180, 200, 25);
        _panel.add(_labelRestBetrag);

        //        _vorstellungLabel = new JLabel("Ausgewählte Vorstellung:");
        //        _vorstellungLabel.setBounds(10, 20, 200, 25);
        //        _panel.add(_vorstellungLabel);

        _vorstellung = new JLabel("");
        _vorstellung.setBounds(10, 20, 800, 25);
        _panel.add(_vorstellung);

        _preis = new JLabel("Preis: ");
        _preis.setBounds(10, 70, 200, 25);
        _panel.add(_preis);

        _preisAnzeige = new JLabel("");
        _preisAnzeige.setBounds(100, 70, 200, 25);
        _panel.add(_preisAnzeige);

        _restBetrag = new JLabel("");
        _restBetrag.setBounds(100, 180, 200, 25);
        _panel.add(_restBetrag);

        //erstellt Buttonpanel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        _berechne = new JButton("Rest Betrag berechnen");
        buttonPanel.add(_berechne);
        _bestätigen = new JButton("OK");
        buttonPanel.add(_bestätigen);
        _abbrechen = new JButton("Abbrechen");
        buttonPanel.add(_abbrechen);

        _FehlerLabel = new JLabel(" ");
        _FehlerLabel.setBounds(10, 230, 200, 25);
        _panel.add(_FehlerLabel);

        _window.add(_panel, BorderLayout.CENTER);
        _window.setSize(500, 500);
        _window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        _window.setTitle("Barzahlung Window");
        _window.setVisible(true);
        _window.setLocationRelativeTo(null);
        _window.add(buttonPanel, BorderLayout.PAGE_END);

    }

    public static void main(String[] args)
    {
        new BarZahlungWerkzeugUI();

    }

    /**
     * Gibt das Label für die Vorstellung zurück.
     */
    public JLabel getVorstellung()
    {
        return _vorstellung;
    }

    /**
     * Gibt das Label für den Preis zurück.
     */
    public JLabel getPreisAnzeige()
    {
        return _preisAnzeige;
    }

    /**
     * Gibt den Button für Abbrechen zurück.
     */
    public JButton getAbbrechenButton()
    {
        return _abbrechen;
    }

    /**
     * Gibt den Button für Bestätigung zurück.
     */
    public JButton getOKButton()
    {
        return _bestätigen;
    }

    public JFrame getWindow()
    {
        return _window;
    }

    public JTextField getKundenBetrag()
    {
        return _kundenBetrag;
    }

    public JLabel getRestBetrag()
    {
        return _restBetrag;
    }

    public JLabel getFehlerLabel()
    {
        return _FehlerLabel;
    }

    public JButton getBerechneButton()
    {
        return _berechne;
    }

}
