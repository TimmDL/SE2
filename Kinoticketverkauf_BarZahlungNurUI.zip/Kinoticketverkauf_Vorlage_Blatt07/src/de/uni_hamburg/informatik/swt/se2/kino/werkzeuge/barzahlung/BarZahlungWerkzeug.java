package de.uni_hamburg.informatik.swt.se2.kino.werkzeuge.barzahlung;

import de.uni_hamburg.informatik.swt.se2.kino.materialien.Vorstellung;

public class BarZahlungWerkzeug
{
    private BarZahlungWerkzeugUI _ui;

    private Vorstellung _vorstellung;

    /**
     * Initialisiert das BarZahlungWerkzeug.
     */
    public BarZahlungWerkzeug(Vorstellung _vorstellung, int _preis)
    {
        _ui = new BarZahlungWerkzeugUI();

    }

}
