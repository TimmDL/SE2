package de.uni_hamburg.informatik.swt.se2.kino.werkzeuge.barzahlung;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

/**
 * Das UI des {@link BarZahlungWerkzeug}.
 * 
 * @author Duy
 * @version SoSe 2020
 */
public class BarZahlungWerkzeugUI
{
    private JFrame _window;

    private JPanel _panel;

    private JButton _bestätigen;
    private JButton _abbrechen;

    private JLabel _label;
    private JLabel _labelKundenBetrag;
    private JLabel _labelRestBetrag;
    private JLabel _vorstellung;
    private JLabel _vorstellungLabel;
    private JLabel _preis;

    private JTextField _kundenBetrag;

    private JLabel _restBetrag;
    private JLabel _preisAnzeige;

    public BarZahlungWerkzeugUI()
    {
        //erstellt das Fenster
        _window = new JFrame();

        //erstellt den Panel
        _panel = new JPanel();
        //_panel.setBorder(BorderFactory.createEmptyBorder(30, 30, 10, 30));
        _panel.setLayout(null);

        //erstellt den Text KundenBetrag
        _labelKundenBetrag = new JLabel("KundenBetrag: ");
        _labelKundenBetrag.setBounds(10, 120, 200, 25);
        _panel.add(_labelKundenBetrag);

        //erstellt den Feld, wo man Geld eingeben kann
        _kundenBetrag = new JTextField(20);
        _kundenBetrag.setBounds(100, 120, 200, 25);
        _panel.add(_kundenBetrag);

        _labelRestBetrag = new JLabel("Restbetrag: ");
        _labelRestBetrag.setBounds(10, 180, 200, 25);
        _panel.add(_labelRestBetrag);

        _vorstellungLabel = new JLabel("Ausgewählte Vorstellung:");
        _vorstellungLabel.setBounds(10, 20, 200, 25);
        _panel.add(_vorstellungLabel);

        _vorstellung = new JLabel("X-men");
        _vorstellung.setBounds(200, 20, 300, 25);
        _panel.add(_vorstellung);

        _preis = new JLabel("Preis: ");
        _preis.setBounds(10, 70, 200, 25);
        _panel.add(_preis);

        _preisAnzeige = new JLabel("25 euro");
        _preisAnzeige.setBounds(100, 70, 200, 25);
        _panel.add(_preisAnzeige);

        _restBetrag = new JLabel("5 euro");
        _restBetrag.setBounds(100, 180, 200, 25);
        _panel.add(_restBetrag);

        //erstellt Buttonpanel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        _bestätigen = new JButton("OK");

        buttonPanel.add(_bestätigen);
        _abbrechen = new JButton("Abbrechen");
        buttonPanel.add(_abbrechen);

        _window.add(_panel, BorderLayout.CENTER);
        _window.setSize(500, 300);
        _window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        _window.setTitle("Barzahlung Window");
        _window.setVisible(true);
        _window.setLocationRelativeTo(null);
        _window.add(buttonPanel, BorderLayout.PAGE_END);

    }

    public static void main(String[] args)
    {
        new BarZahlungWerkzeugUI();

    }

    /**
     * Gibt das Label für die Vorstellung zurück.
     */
    public JLabel getVorstellung()
    {
        return _vorstellung;
    }

    public JLabel getPreis()
    {
        return _preis;
    }

}
